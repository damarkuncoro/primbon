interface WetonResult {
    hari: string;
    pasaran: string;
    weton: string;
    neptu: number;
    neptuKamarokam?: number;
}
/**
 * Menghitung weton dari tanggal masehi.
 * @param date - Tanggal masehi.
 * @returns - Informasi weton.
 */
declare const calculateWeton: (date: Date) => WetonResult;

/**
 * Menghitung pasaran Jawa dari tanggal masehi.
 * @param date - Tanggal masehi.
 * @returns - Nama pasaran.
 */
declare const calculatePasaran: (date: Date) => string;

/**
 * Menghitung nilai neptu weton.
 * @param hari - Nama hari masehi.
 * @param pasaran - Nama pasaran Jawa.
 * @returns - Nilai neptu.
 */
declare const calculateNeptu: (hari: string, pasaran: string) => number;

interface KalenderJawaResult {
    tanggal: number;
    bulan: string;
    tahun: number;
    namaTahun: string;
}
declare const calculateKalenderJawa: (date: Date) => KalenderJawaResult;

interface PranataMangsaResult {
    id: string;
    nama: string;
    mulai: string;
    akhir: string;
    candra: string;
    sifat: string;
    kesehatan: string;
    karir: string;
    rejeki: string;
    jodoh?: string;
    batu_permata?: string;
    warna?: string;
    bunga?: string;
}
declare const calculatePranataMangsa: (date: Date) => PranataMangsaResult | null;

/**
 * Paringkelan (Sadwara) - Siklus 6 Harian
 *
 * Dalam tradisi Jawa, Paringkelan dihitung berdasarkan neptu weton (hari + pasaran).
 * Siklus ini digunakan untuk menentukan hari baik/buruk dalam berbagai aktivitas.
 *
 * Referensi: Primbon Betaljemur Adammakna
 */
interface SadwaraResult {
    /** Nama Paringkelan dalam Bahasa Indonesia */
    nama: string;
    /** Nama Paringkelan dalam Bahasa Jawa */
    namaJawa: string;
    /** Nilai neptu Paringkelan */
    neptu: number;
    /** Watak/karakter Paringkelan (nama hewan) */
    watak: string;
    /** Deskripsi detail Paringkelan */
    deskripsi: string;
}
/**
 * Menghitung Paringkelan (Sadwara) dari tanggal masehi.
 * Paringkelan dihitung dari neptu weton (hari + pasaran) modulo 6
 *
 * @param date - Tanggal masehi
 * @returns - Informasi Paringkelan lengkap
 */
declare const calculateSadwara: (date: Date) => SadwaraResult;
/**
 * Daftar nama Paringkelan lengkap
 */
declare const SADWARA_NAMES: string[];

/**
 * Padewan (Asatawara) - Siklus 8 Harian
 *
 * Asatawara berasal dari bahasa Jawa "Asata" (delapan) dan "wara" (hari)
 * Siklus ini menghitung hari berdasarkan tanggal dalam kalender Jawa
 * yang dihitung dari hari markets (Legi, Pahing, Pon, Wage, Kliwon)
 *
 * @reference Primbon Betaljemur Adammakna, Primbon Lukmanakim
 */
interface AsatawaraResult {
    /** Nama Padewan dalam Bahasa Indonesia */
    nama: string;
    /** Nama Padewan dalam Bahasa Jawa (Krama Alus) */
    namaJawa: string;
    /** Watak/karakter Padewan */
    watak: string;
    /** Deskripsi detail Padewan */
    deskripsi: string;
    /** Nilai neptu */
    neptu: number;
}
/**
 * Menghitung Padewan (Asatawara) dari tanggal masehi.
 * Padewan dihitung dari hari pasar (pasaran) yang dimulai dari Legi
 * Siklus: Legi -> Pahing -> Pon -> Wage -> Kliwon -> Legi -> ...
 *
 * @param date - Tanggal masehi
 * @returns - Informasi Padewan lengkap
 */
declare const calculateAsatawara: (date: Date) => AsatawaraResult;
/**
 * Daftar nama Padewan lengkap
 */
declare const ASATAWARA_NAMES: string[];

/**
 * Padangon (Sangawara) - Siklus 9 Harian
 *
 * Sangawara berasal dari bahasa Jawa "Sanga" (sembilan) dan "wara" (hari)
 * Siklus ini menghitung hari berdasarkan weton dengan periode 9 hari
 *
 * @reference Primbon Betaljemur Adammakna, Primbon Lukmanakim
 */
interface SangawaraResult {
    /** Nama Padangon dalam Bahasa Indonesia */
    nama: string;
    /** Nama Padangon dalam Bahasa Jawa (Krama Alus) */
    namaJawa: string;
    /** Watak/karakter Padangon */
    watak: string;
    /** Deskripsi detail Padangon */
    deskripsi: string;
    /** Nilai neptu */
    neptu: number;
}
/**
 * Menghitung Padangon (Sangawara) dari tanggal masehi.
 * Padangon dihitung dari weton (hari + pasaran) modulo 9
 *
 * @param date - Tanggal masehi
 * @returns - Informasi Padangon lengkap
 */
declare const calculateSangawara: (date: Date) => SangawaraResult;
/**
 * Daftar nama Padangon lengkap
 */
declare const SANGAWARA_NAMES: string[];

/**
 * Hari Naas - Perhitungan hari kewaspadaan
 *
 * Dalam tradisi Jawa, Hari Naas adalah hari di mana seseorang
 * sebaiknya lebih waspada dan menghindari aktivitas berisiko.
 * Perhitungan berdasarkan weton lahir dan siklus tertentu.
 *
 * @reference Primbon Betaljemur Adammakna, Primbon Lukmanakim
 */
interface HariNaasResult {
    /** Nama hari naas */
    nama: string;
    /** Watak/karakter hari naas */
    watak: string;
    /** Penjelasan tentang hari naas */
    deskripsi: string;
    /** Saran untuk hari naas */
    saran: string;
}
/**
 * Menghitung Hari Naas berdasarkan tanggal lahir.
 * Hari Naas dihitung dari weton dan siklus 7 tahun
 *
 * @param date - Tanggal lahir
 * @returns - Informasi Hari Naas lengkap
 */
declare const calculateHariNaas: (date: Date) => HariNaasResult;
/**
 * Mendapatkan daftar semua Hari Naas
 */
declare const getAllHariNaas: () => HariNaasResult[];
declare const HARI_NAAS_NAMES: string[];

/**
 * Siklus Rejeki (Pal Srigati) - Fluktuasi Keberuntungan
 *
 * Dalam tradisi Jawa, siklus rejeki/fluktuasi kehidupan seseorang
 * dihitung berdasarkan weton dan dibagi dalam periode tertentu
 * (biasanya per 6 tahun dalam primbon).
 *
 * @reference Primbon Betaljemur Adammakna, Primbon Lukmanakim
 */
interface RejekiPoint {
    /** Usia pada titik ini */
    usia: number;
    /** Tingkat rejeki: 1-10 */
    level: number;
    /** Penjelasan kondisi */
    kondisi: string;
}
interface SiklusRejekiResult {
    /** Weton lahir */
    weton: string;
    /** Neptu weton */
    neptu: number;
    /** Siklus dasar (0-7) */
    siklusDasar: number;
    /** Array titik-titik fluktuasi rejeki */
    grafik: RejekiPoint[];
    /** Interpretasi umum */
    interpretasi: string;
    /** Saran berdasarkan siklus */
    saran: string;
}
/**
 * Menghitung Siklus Rejeki (Pal Srigati) berdasarkan tanggal lahir.
 * Menghasilkan grafik fluktuasi keberuntungan dalam rentang usia 0-80 tahun
 *
 * @param date - Tanggal lahir
 * @param maxUsia - Usia maksimum untuk grafik (default: 80)
 * @returns - Informasi Siklus Rejeki lengkap
 */
declare const calculateSiklusRejeki: (date: Date, maxUsia?: number) => SiklusRejekiResult;
/**
 * Mendapatkan level rejeki untuk usia tertentu
 *
 * @param date - Tanggal lahir
 * @param usia - Usia yang ingin dicek
 * @returns - Level rejeki (1-10) dan kondisi
 */
declare const getRejekiByUsia: (date: Date, usia: number) => {
    level: number;
    kondisi: string;
};

/**
 * Lintang (Zodiak Jawa) - Perhitungan Bintang Lahir
 *
 * Dalam tradisi Jawa, Lintang atau Zodiak Jawa adalah penentuan
 * bintang atau rasi yang tampak pada malam hari kelahiran.
 * Dihitung berdasarkan weton dan hari dalam kalender Jawa.
 *
 * @reference Primbon Betaljemur Adammakna, Primbon Lukmanakim
 */
interface LintangResult {
    /** Nama Lintang */
    nama: string;
    /** Nama alternatif */
    namaAlt?: string;
    /** Watak/karakter Lintang */
    watak: string;
    /** Deskripsi detail */
    deskripsi: string;
    /** Sifat yang dominan */
    sifat: string[];
    /** Kecocokan dengan Lintang lain */
    kompatibel: string[];
    /** Tidak kompatibel dengan */
    tidakKompatibel: string[];
}
/**
 * Menghitung Lintang (Zodiak Jawa) dari tanggal lahir.
 * Lintang dihitung berdasarkan weton (hari + pasaran)
 *
 * @param date - Tanggal lahir
 * @returns - Informasi Lintang lengkap
 */
declare const calculateLintang: (date: Date) => LintangResult;
/**
 * Mendapatkan Lintang berdasarkan tahun dalam siklus 25 tahun
 */
declare const getLintangByYear: (tahun: number) => LintangResult;
/**
 * Daftar semua nama Lintang
 */
declare const LINTANG_NAMES: string[];

/**
 * Interface for monthly weton result
 */
interface WetonMonthResult {
    tanggal: number;
    hari: string;
    pasaran: string;
    weton: string;
    neptu: number;
    neptuKamarokam: number;
}

interface WatakResult {
    weton: string;
    sifat: string[];
    deskripsi: string;
    detail: {
        hari: {
            nama: string;
            beredar?: string;
            sifat: string[];
        };
        pasaran: {
            nama: string;
            gambaran?: string;
            binatang?: any[];
            sifat: string[];
        };
    };
}
/**
 * Mendapatkan watak berdasarkan weton.
 * @param date - Tanggal masehi.
 * @returns - Informasi watak.
 */
declare const getWatak: (date: Date) => WatakResult;
/**
 * Mendapatkan watak berdasarkan tanggal Jawa (1-30).
 * @param tanggal - Tanggal Jawa.
 * @returns - Deskripsi watak.
 */
declare const getWatakTanggalJawa: (tanggal: number | string) => string;
interface BulanWatakResult {
    neptu: number;
    watak: string;
}
/**
 * Mendapatkan watak berdasarkan Bulan Jawa.
 * @param bulan - Nama bulan Jawa.
 * @returns - { neptu, watak }
 */
declare const getWatakBulanJawa: (bulan: string) => BulanWatakResult;

interface JodohResult {
    personA: {
        hari: string;
        pasaran: string;
        weton: string;
        neptu: number;
        neptuKamarokam?: number;
    };
    personB: {
        hari: string;
        pasaran: string;
        weton: string;
        neptu: number;
        neptuKamarokam?: number;
    };
    totalNeptu: number;
    sisa: number;
    totalNeptuKamarokam?: number;
    sisaKamarokam?: number;
    kategori: string;
    arti: string;
}
/**
 * Menghitung kecocokan jodoh berdasarkan dua tanggal lahir.
 * @param dateA - Tanggal lahir orang pertama.
 * @param dateB - Tanggal lahir orang kedua.
 * @returns - Hasil kecocokan jodoh.
 */
declare const calculateJodoh: (dateA: Date, dateB: Date) => JodohResult;

interface HariBaikResult {
    keperluan: string;
    bulan: string | null;
    rekomendasi: string[];
}
/**
 * Menentukan hari baik untuk keperluan tertentu.
 * @param keperluan - Keperluan (nikah, pindah_rumah, usaha).
 * @param bulan - Bulan Jawa (opsional).
 * @returns - { keperluan, bulan, rekomendasi }
 */
declare const getHariBaik: (keperluan: string, bulan?: string) => HariBaikResult;

interface GarisHidupResult {
    angka: number;
    karakter: string;
}
/**
 * Mendapatkan informasi karakter Garis Hidup berdasarkan tanggal lahir.
 * @param date - Tanggal lahir.
 * @returns - { angka, karakter }
 */
declare const getGarisHidup: (date: Date) => GarisHidupResult;

interface WukuResult {
    nama: string;
    watak: string;
}
/**
 * Menghitung wuku berdasarkan tanggal masehi.
 * @param date - Tanggal masehi.
 * @returns - { nama, watak }
 */
declare const calculateWuku: (date: Date) => WukuResult;

/**
 * Interface for monthly wuku result
 */
interface WukuMonthResult {
    tanggal: number;
    hari: string;
    wuku: string;
    weton: string;
    neptu: number;
}

interface SelapanResult {
    jumlahSelapan: number;
    hariKe: number;
    sisaHari: number;
}
/**
 * Menghitung informasi siklus 35 hari (Selapan).
 * @param tglLahir - Tanggal lahir.
 * @param tglSekarang - Tanggal sekarang.
 * @returns - { jumlahSelapan, hariKe, sisaHari }
 */
declare const calculateSelapan: (tglLahir: Date, tglSekarang?: Date) => SelapanResult;

/**
 * Sistem Lokalisasi untuk Library Primbon
 * Mendukung: Bahasa Indonesia (id), Bahasa Jawa (jv), Bahasa Inggris (en)
 */
type Locale = 'id' | 'jv' | 'en';
/**
 * Interface untuk terjemahan
 */
interface LocaleStrings {
    hari: {
        minggu: string;
        senin: string;
        selasa: string;
        rabu: string;
        kamis: string;
        jumat: string;
        sabtu: string;
    };
    pasaran: {
        legi: string;
        pahing: string;
        pon: string;
        wage: string;
        kliwon: string;
    };
    weton: {
        title: string;
        neptu: string;
        neptuKamarokam: string;
    };
    jodoh: {
        title: string;
        kategori: string;
        arti: string;
        personA: string;
        personB: string;
        totalNeptu: string;
        sisa: string;
    };
    sadwara: {
        title: string;
        nama: string;
        watak: string;
        deskripsi: string;
        neptu: string;
    };
    asatawara: {
        title: string;
        nama: string;
        watak: string;
        deskripsi: string;
        neptu: string;
    };
    sangawara: {
        title: string;
        nama: string;
        watak: string;
        deskripsi: string;
        neptu: string;
    };
    pranataMangsa: {
        title: string;
        nama: string;
        awal: string;
        akhir: string;
    };
    wuku: {
        title: string;
        nama: string;
        watak: string;
    };
    watak: {
        title: string;
        sifat: string;
    };
    garisHidup: {
        title: string;
        angka: string;
        karakter: string;
    };
    hariBaik: {
        title: string;
        keperluan: string;
        bulan: string;
        rekomendasi: string;
    };
    common: {
        tanggal: string;
        bulan: string;
        tahun: string;
        hasil: string;
    };
}
/**
 * Get current locale
 */
declare const getLocale: () => Locale;
/**
 * Set current locale
 */
declare const setLocale: (locale: Locale) => void;
/**
 * Get translation strings for current locale
 */
declare const t: () => LocaleStrings;
/**
 * Get translation strings for specific locale
 */
declare const getTranslations: (locale: Locale) => LocaleStrings;
/**
 * Get day name in current locale
 */
declare const translateHari: (nama: string) => string;
/**
 * Get pasaran name in current locale
 */
declare const translatePasaran: (nama: string) => string;

/**
 * Sistem Referensi Kitab Primbon
 *
 * Primbon memiliki berbagai versi/rujukan dari kitab-kitab klasik:
 * - Betaljemur Adammakna (Kitab primbon tertua, karya Sunan Kalijaga)
 * - Primbon Lukmanakim (Versi komprehensif dari Arabia)
 * - Primbon Mustika Waktu (Kitab primbon dari Mataram)
 * - Primbon IJub (Kitab primbon dari komunitas Muslim Jawa)
 */
type KitabReference = 'betaljemur' | 'lukmanakim' | 'mustikawaktu' | 'ijub' | 'default';
interface KitabInfo {
    id: KitabReference;
    nama: string;
    namaJawa: string;
    deskripsi: string;
    tahun?: string;
}
/**
 * Daftar kitab referensi yang tersedia
 */
declare const KITAB_REFERENCES: Record<KitabReference, KitabInfo>;
/**
 * Mendapatkan informasi kitab berdasarkan ID
 */
declare const getKitabInfo: (kitabId: KitabReference) => KitabInfo;
/**
 * Mendapatkan daftar semua kitab referensi
 */
declare const getAllKitabReferences: () => KitabInfo[];
/**
 * Mendapatkan neptu hari berdasarkan kitab referensi
 */
declare const getNeptuHari: (hari: string, kitab?: KitabReference) => number;
/**
 * Mendapatkan neptu pasaran berdasarkan kitab referensi
 */
declare const getNeptuPasaran: (pasaran: string, kitab?: KitabReference) => number;
/**
 * Mendapatkan neptu pasaran dalam sistem Kamarokam
 */
declare const getNeptuPasaranKamarokam: (pasaran: string) => number;

/**
 * Primbon Plugin System
 *
 * Modular dan Extensible Architecture
 * Allows developers to extend primbon functionality with custom plugins
 */
/**
 * Date input type - accepts Date, string, or number
 */
type DateInput = Date | string | number;
/**
 * Base Plugin Interface
 * All plugins must implement this interface
 */
interface PrimbonPlugin {
    /** Unique identifier for the plugin */
    id: string;
    /** Human-readable name */
    name: string;
    /** Plugin version */
    version: string;
    /** Description of what the plugin does */
    description?: string;
    /** Calculate result from date */
    calculate: (date: Date) => unknown;
    /** Optional: Validate input */
    validate?: (input: DateInput) => boolean;
    /** Optional: Get metadata */
    getMeta?: () => Record<string, unknown>;
}
/**
 * Register a plugin
 */
declare const registerPlugin: (plugin: PrimbonPlugin) => void;
/**
 * Unregister a plugin
 */
declare const unregisterPlugin: (pluginId: string) => boolean;
/**
 * Get a plugin by id
 */
declare const getPlugin: (pluginId: string) => PrimbonPlugin | undefined;
/**
 * Get all plugins
 */
declare const getAllPlugins: () => PrimbonPlugin[];
/**
 * Check if plugin exists
 */
declare const hasPlugin: (pluginId: string) => boolean;
/**
 * Create a primbon plugin helper
 */
declare const createPlugin: (id: string, name: string, version: string, calculate: (date: Date) => unknown, options?: {
    description?: string;
    validate?: (input: DateInput) => boolean;
    getMeta?: () => Record<string, unknown>;
}) => PrimbonPlugin;

declare const primbon: {
    /**
     * Mendapatkan informasi weton lengkap.
     * @param tanggal - Tanggal masehi.
     * @returns - { hari, pasaran, weton, neptu }
     */
    weton: (tanggal: Date | string | number) => WetonResult;
    /**
     * Mendapatkan tanggal Jawa lengkap (Masehi ke Jawa).
     * @param tanggal - Tanggal masehi.
     * @returns - { tanggal, bulan, tahun, namaTahun }
     */
    kalenderJawa: (tanggal: Date | string | number) => KalenderJawaResult;
    /**
     * Mendapatkan informasi Pranata Mangsa (Kalender Musim Jawa).
     * @param tanggal - Tanggal masehi.
     * @returns - Detail Mangsa.
     */
    pranataMangsa: (tanggal: Date | string | number) => PranataMangsaResult | null;
    /**
     * Mendapatkan pasaran Jawa.
     * @param tanggal - Tanggal masehi.
     * @returns - Legi, Pahing, Pon, Wage, Kliwon.
     */
    pasaran: (tanggal: Date | string | number) => string;
    /**
     * Menghitung nilai neptu.
     * @param hari - Nama hari.
     * @param pasaran - Nama pasaran.
     * @returns - Nilai neptu.
     */
    neptu: (hari: string, pasaran: string) => number;
    /**
     * Mendapatkan watak berdasarkan weton.
     * @param tanggal - Tanggal masehi.
     * @returns - { weton, sifat }
     */
    watak: (tanggal: Date | string | number) => WatakResult;
    /**
     * Mendapatkan watak berdasarkan tanggal Jawa (1-30).
     * @param tanggal - Tanggal Jawa.
     * @returns - Deskripsi watak.
     */
    watakTanggalJawa: (tanggal: number | string) => string;
    /**
     * Mendapatkan watak berdasarkan Bulan Jawa.
     * @param bulan - Nama bulan Jawa.
     * @returns - { neptu, watak }
     */
    watakBulanJawa: (bulan: string) => BulanWatakResult;
    /**
     * Menghitung kecocokan jodoh.
     * @param tglA - Tanggal lahir orang pertama.
     * @param tglB - Tanggal lahir orang kedua.
     * @returns - Hasil kecocokan jodoh.
     */
    jodoh: (tglA: Date | string | number, tglB: Date | string | number) => JodohResult;
    /**
     * Menentukan hari baik untuk keperluan tertentu.
     * @param keperluan - Keperluan (nikah, pindah_rumah, usaha).
     * @param bulan - Bulan Jawa (opsional).
     * @returns - { keperluan, bulan, rekomendasi }
     */
    hariBaik: (keperluan: string, bulan?: string) => HariBaikResult;
    /**
     * Mendapatkan informasi Garis Hidup (Numerologi) berdasarkan tanggal lahir.
     * @param tanggal - Tanggal lahir.
     * @returns - { angka, karakter }
     */
    garisHidup: (tanggal: Date | string | number) => GarisHidupResult;
    /**
     * Menentukan wuku berdasarkan tanggal masehi.
     * @param tanggal - Tanggal masehi.
     * @returns - { nama, watak }
     */
    wuku: (tanggal: Date | string | number) => WukuResult;
    /**
     * Menghitung informasi siklus 35 hari (Selapan).
     * @param tglLahir - Tanggal lahir.
     * @param tglSekarang - Tanggal sekarang.
     * @returns - { jumlahSelapan, hariKe, sisaHari }
     */
    selapan: (tglLahir: Date | string | number, tglSekarang?: Date | string | number) => SelapanResult;
    /**
     * Mendapatkan tabel weton untuk bulan tertentu.
     * @param tahun - Tahun Masehi.
     * @param bulan - Bulan Masehi (1-12).
     * @returns - Array data weton untuk setiap hari dalam bulan.
     */
    wetonMonth: (tahun: number, bulan: number) => WetonMonthResult[];
    /**
     * Mendapatkan tabel wuku untuk bulan tertentu.
     * @param tahun - Tahun Masehi.
     * @param bulan - Bulan Masehi (1-12).
     * @returns - Array data wuku untuk setiap hari dalam bulan.
     */
    wukuMonth: (tahun: number, bulan: number) => WukuMonthResult[];
    /**
     * Menghitung Paringkelan (Sadwara) - Siklus 6 harian.
     * @param tanggal - Tanggal masehi.
     * @returns - Informasi Paringkelan lengkap.
     */
    sadwara: (tanggal: Date | string | number) => SadwaraResult;
    /**
     * Menghitung Padewan (Asatawara) - Siklus 8 harian.
     * @param tanggal - Tanggal masehi.
     * @returns - Informasi Padewan lengkap.
     */
    asatawara: (tanggal: Date | string | number) => AsatawaraResult;
    /**
     * Menghitung Padangon (Sangawara) - Siklus 9 harian.
     * @param tanggal - Tanggal masehi.
     * @returns - Informasi Padangon lengkap.
     */
    sangawara: (tanggal: Date | string | number) => SangawaraResult;
    /**
     * Mendapatkan locale saat ini.
     */
    getLocale: () => Locale;
    /**
     * Mengatur locale untuk internasionalisasi.
     * @param locale - Locale yang diinginkan ('id', 'jv', 'en')
     */
    setLocale: (locale: Locale) => void;
    /**
     * Mendapatkan terjemahan untuk locale saat ini.
     */
    translate: () => LocaleStrings;
    /**
     * Mendapatkan terjemahan untuk locale tertentu.
     * @param locale - Locale yang diinginkan.
     */
    getTranslations: (locale: Locale) => LocaleStrings;
    /**
     * Mendapatkan informasi kitab referensi.
     * @param kitabId - ID kitab referensi.
     */
    getKitabInfo: (kitabId: KitabReference) => KitabInfo;
    /**
     * Mendapatkan daftar semua kitab referensi.
     */
    getAllKitabReferences: () => KitabInfo[];
    /**
     * Menghitung Hari Naas (Hari Kewaspadaan).
     * @param tanggal - Tanggal lahir.
     * @returns - Informasi Hari Naas lengkap.
     */
    hariNaas: (tanggal: Date | string | number) => HariNaasResult;
    /**
     * Mendapatkan semua daftar Hari Naas.
     */
    getAllHariNaas: () => HariNaasResult[];
    /**
     * Menghitung Siklus Rejeki (Pal Srigati).
     * @param tanggal - Tanggal lahir.
     * @param maxUsia - Usia maksimum (default: 80).
     * @returns - Informasi Siklus Rejeki lengkap dengan grafik.
     */
    siklusRejeki: (tanggal: Date | string | number, maxUsia?: number) => SiklusRejekiResult;
    /**
     * Mendapatkan level rejeki untuk usia tertentu.
     * @param tanggal - Tanggal lahir.
     * @param usia - Usia yang ingin dicek.
     * @returns - Level rejeki dan kondisi.
     */
    rejekiByUsia: (tanggal: Date | string | number, usia: number) => {
        level: number;
        kondisi: string;
    };
    /**
     * Menghitung Lintang (Zodiak Jawa) - Bintang Lahir.
     * @param tanggal - Tanggal lahir.
     * @returns - Informasi Lintang lengkap.
     */
    lintang: (tanggal: Date | string | number) => LintangResult;
};

export { ASATAWARA_NAMES, type DateInput, HARI_NAAS_NAMES, type HariNaasResult, KITAB_REFERENCES, type KitabInfo, type KitabReference, LINTANG_NAMES, type LintangResult, type Locale, type LocaleStrings, type PrimbonPlugin, type RejekiPoint, SADWARA_NAMES, SANGAWARA_NAMES, type SiklusRejekiResult, calculateAsatawara, calculateHariNaas, calculateJodoh, calculateKalenderJawa, calculateLintang, calculateNeptu, calculatePasaran, calculatePranataMangsa, calculateSadwara, calculateSangawara, calculateSelapan, calculateSiklusRejeki, calculateWeton, calculateWuku, createPlugin, primbon as default, getAllHariNaas, getAllKitabReferences, getAllPlugins, getGarisHidup, getHariBaik, getKitabInfo, getLintangByYear, getLocale, getNeptuHari, getNeptuPasaran, getNeptuPasaranKamarokam, getPlugin, getRejekiByUsia, getTranslations, getWatak, getWatakBulanJawa, getWatakTanggalJawa, hasPlugin, registerPlugin, setLocale, t, translateHari, translatePasaran, unregisterPlugin };
